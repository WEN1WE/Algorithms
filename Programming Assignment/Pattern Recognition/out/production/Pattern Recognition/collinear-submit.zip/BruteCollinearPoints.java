import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private final ArrayList<LineSegment> lineSegments = new ArrayList<>();
    private final int n;

    public BruteCollinearPoints(Point[] points) {
        if (points == null || hasNull(points)) {
            throw new java.lang.IllegalArgumentException();
        }

        n = points.length;

        // time : nlogn
        Arrays.sort(points);
        if (hasDuplicate(points)) {
            throw new java.lang.IllegalArgumentException();
        }

        for (int i0 = 0; i0 < n; i0++) {
            if (points[i0] == null) {
                throw new java.lang.IllegalArgumentException();
            }

            for (int i1 = i0 + 1; i1 < n; i1++) {
                for (int i2 = i1 + 1; i2 < n; i2++) {
                    for (int i3 = i2 + 1; i3 < n; i3++) {
                        double s0 = points[i0].slopeTo(points[i1]);
                        double s1 = points[i1].slopeTo(points[i2]);
                        double s2 = points[i2].slopeTo(points[i3]);
                        if (Double.compare(s0, s1) == 0 && Double.compare(s1, s2) == 0) {
                            lineSegments.add(new LineSegment(points[i0], points[i3]));
                        }
                    }
                }
            }
        }
    }

    public int numberOfSegments() {
        return lineSegments.size();
    }

    public LineSegment[] segments() {
        return lineSegments.toArray(new LineSegment[0]);
    }

    private boolean hasNull(Point[] points) {
        for (Point p : points) {
            if (p == null) {
                return true;
            }
        }
        return false;
    }

    private boolean hasDuplicate(Point[] points) {
        for (int i = 0; i < n - 1; i++) {
            if (points[i].compareTo(points[i + 1]) == 0) {
                return true;
            }
        }
        return false;
    }
}
