import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int n;
    private int openSites;
    private final int virtualTop;
    private final int virtualBottom;
    private int[] grids;
    private final WeightedQuickUnionUF UF;

    public Percolation(int n) {
        if (n <= 0) {
            throw new java.lang.IllegalArgumentException("n must be bigger than 0");
        }

        this.n = n;
        this.openSites = 0;
        this.virtualTop = n * n;
        this.virtualBottom = n * n + 1;
        grids = new int[n * n + 2];
        grids[n * n] = 1;
        grids[n * n + 1] = 1;

        UF = new WeightedQuickUnionUF(n * n + 2);
    }

    public void open(int row, int col) {
        validRowAndCol(row, col);

        int index = getIndex(row, col);
        if (grids[index] == 0) {
            grids[index] = 1;
            this.openSites += 1;
        }

        connected(index, row, col - 1);
        connected(index, row, col + 1);
        connected(index, row - 1, col);
        connected(index, row + 1, col);

        if (isTop(row, col)) {
            UF.union(index, virtualTop);
        }

        if (isBottom(row, col)) {
            UF.union(index, virtualBottom);
        }

    }

    public boolean isOpen(int row, int col) {
        validRowAndCol(row, col);
        return grids[getIndex(row, col)] == 1;
    }

    public boolean isFull(int row, int col) {
        validRowAndCol(row, col);
        return UF.connected(getIndex(row, col), virtualTop);

    }

    public int numberOfOpenSites() {
        return this.openSites;
    }

    public boolean percolates() {
        return UF.connected(virtualTop, virtualBottom);
    }

    private boolean isLegal(int row, int col) {
        return row >= 1 && row <= this.n && col >= 1 && col <= this.n;
    }

    private int getIndex(int row, int col) {
        return this.n * (row - 1) + col - 1;
    }

    private void connected(int index, int row, int col) {
        if (isLegal(row, col) && isOpen(row, col)) {
            UF.union(index, getIndex(row, col));
        }
    }

    private boolean isTop(int row, int col) {
        return isLegal(row, col) && row == 1;
    }

    private boolean isBottom(int row, int col) {
        return isLegal(row, col) && row == this.n;
    }

    private void validRowAndCol(int row, int col) {
        if (!isLegal(row, col)) {
            throw new java.lang.IllegalArgumentException("invalid range of row or col");
        }
    }
}
